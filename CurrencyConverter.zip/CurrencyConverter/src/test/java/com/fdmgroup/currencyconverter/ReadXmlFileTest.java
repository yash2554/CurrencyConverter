package com.fdmgroup.currencyconverter;

import static org.junit.Assert.*;

import java.io.IOException;

import org.jdom2.JDOMException;
import org.junit.Before;
import org.junit.Test;

public class ReadXmlFileTest {

	ReadXmlFile readXml;
	String url;

	@Before
	public void setUp() throws Exception {
		readXml = new ReadXmlFile();
		url = "./src/main/resources/eurofxref-daily.xml";
	}

	@Test
	public void test_extractXml_Input_XML_file_and_1USD_toINR_return() throws JDOMException, IOException {
		readXml.extractXml(url);
		double actual = readXml.currencyConvert("USD", "INR", 1);
		assertEquals(64.92490453966906, actual, 20);
	}

	@Test
	public void test_extractXml_Input_XML_file_and_10USD_toUSD_return() throws JDOMException, IOException {
		readXml.extractXml(url);
		double actual = readXml.currencyConvert("USD", "USD", 10);
		assertEquals(10.0, actual, 20);
	}

	@Test
	public void test_extractXml_Input_XML_file_and_0USD_to0INR_return() throws JDOMException, IOException {
		readXml.extractXml(url);
		double actual = readXml.currencyConvert("USD", "inr", 0);
		assertEquals(0.0, actual, 20);
	}

	@Test(expected = IllegalArgumentException.class)
	public void test_extractXml_Input_XML_file_and_anyUSD_toUSD_throwException() throws JDOMException, IOException {
		readXml.extractXml(url);
		readXml.currencyConvert("USD", "USD", -1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void test_extractXml_Input_XML_file_and_anyCurrency_toanyCurrency_throwException()
			throws JDOMException, IOException {
		readXml.extractXml(url);
		readXml.currencyConvert("","",10);
	}
	
	@Test(expected = NullPointerException.class)
	public void test_extractXml_Input_XML_file_and_anyCurrency_toUSDCurrency_throwException()
			throws JDOMException, IOException {
		readXml.extractXml(url);
		readXml.currencyConvert("","USD",10);
	}
	
	@Test(expected = NullPointerException.class)
	public void test_extractXml_Input_XML_file_and_USDCurrency_toNullCurrency_throwException()
			throws JDOMException, IOException {
		readXml.extractXml(url);
		readXml.currencyConvert("USD","",10);
	}

}
