package com.fdmgroup.currencyconverter;

import java.io.IOException;
import java.util.Scanner;

import org.jdom2.JDOMException;

/**
 * This file contains logic of main method and also scanner object to get user's
 * inputs
 * 
 * @author yash.patel
 * @version 1.0
 * @since 2017
 *
 */
public class CurrencyConverterMain {
	/**
	 * This is main method which invoke the ReadXmlFile instance and run method
	 * to convert the amount into different currency. the main method contains
	 * Scanner implementation to read the user inputs. it waits for the input
	 * and then it put those arguments into the currencyConvert method which is
	 * one of the methods of ReadXmlFile class.
	 * 
	 * @param args
	 *            this is main method argument
	 * @throws JDOMException
	 *             this is DOM exception
	 * @throws IOException
	 *             this is File I/O exception
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) throws JDOMException, IOException {
		/**
		 * Three variables for the application : amount, from, to where amount
		 * is the user's requested input which user wants to convert. from is
		 * the String typed variable which is From-Currency type to is the
		 * another String typed variable which is To-Currency type consoleIn is
		 * the Scanner object which uses here to read user's inputs through the
		 * console.
		 */
		double amount = 0;
		String from;
		String to;
		Scanner concoleIn = new Scanner(System.in);
		String url = "http://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml";
		// String url = "./src/main/resources/eurofxref-daily.xml";
		ReadXmlFile readFile = new ReadXmlFile();
		/**
		 * This part of the application takes the user inputs and passes those
		 * inputs into the currencyConverter method. There is another method you
		 * can find extractXml which is extracting XML file from the location
		 * which you have provided.
		 */
		System.out.println("Currency Converter\n\n");
		System.out.println("Enter the amount: ");
		amount = concoleIn.nextDouble();

		/**
		 * This part has method call after taking user inputs from the command.
		 */
		readFile.extractXml(url);
		System.out.println("Enter Currency Code(FROM): ");
		from = concoleIn.next();
		System.out.println("Enter Currency Code(TO): ");
		to = concoleIn.next();
		readFile.currencyConvert(from, to, amount);
	}

}
