package com.fdmgroup.currencyconverter;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

/**
 * This file contains logic for parsing the XML file from the URL and also logic
 * to convert the request input into request currency type.
 * 
 * @author yash.patel
 * @version 1.0
 * @since 2017
 *
 */
public class ReadXmlFile {
	File filename;
	public HashMap<String, Double> currencyTable;
	private static final Logger errorLog = Logger.getLogger("ErrorLog");

	/**
	 * extractXml method takes filename as an argument and extract XML file into
	 * usable and understandable data format. it takes the XML file as an
	 * argument create HashMap with key of currency code and value of the
	 * current rate for same.
	 * 
	 * @param file
	 *            this is string argument which contains file name
	 * @return the method returns HashMap for CurrencyTable(currencyCode,rate)
	 * @throws IOException
	 *             this is file I/O exception
	 * @throws JDOMException
	 *             this is JDOM exception
	 */
	public HashMap<String, Double> extractXml(String file) throws JDOMException, IOException {
		PropertyConfigurator.configure("./log4j.properties");
		filename = new File(file);
		SAXBuilder saxBuilder = new SAXBuilder();
		Document document = saxBuilder.build(file);
		Element rootNode = document.getRootElement();
		List<Element> childNode = rootNode.getChildren();
		List<Element> cubeNode = childNode.get(2).getChildren();
		List<Element> todayCubeNode = cubeNode.get(0).getChildren();
		currencyTable = new HashMap<String, Double>();

		for (int i = 0; i < todayCubeNode.size(); i++) {
			String currency = todayCubeNode.get(i).getAttribute("currency").getValue();
			double rate = Double.parseDouble(todayCubeNode.get(i).getAttribute("rate").getValue());
			currencyTable.put(currency, rate);
		}
		System.out.println(currencyTable.keySet() + "\n");
		return currencyTable;
	}

	/**
	 * 
	 * @param from
	 *            String type variable which user has requested as
	 *            "Convert From" currency type code.
	 * @param to
	 *            String type variable which user has requested as "Convert To"
	 *            currency type code.
	 * @param amount
	 *            Double type variable which user has requested as Amount to be
	 *            convert
	 * @return double Result in double type
	 */
	public double currencyConvert(String from, String to, double amount) {
		double convert = 0;
		if (amount < 0) {
			errorLog.error(amount + " non-positive value");
			throw new IllegalArgumentException("Enter positive value");
		}
		if (!currencyTable.containsKey(from.toUpperCase()) && !currencyTable.containsKey(to.toUpperCase())) {
			errorLog.error(from + " or " + to + "Invalid currency code value");
			throw new IllegalArgumentException(from + " or " + to + " is not the valid currency type");
		}
		convert = (currencyTable.get(to.toUpperCase()) * amount) / currencyTable.get(from.toUpperCase());
		System.out.println(amount + " " + from + " --> " + convert + " " + to);
		return convert;
	}

}
